
public interface Predicado<E> {

	public boolean test (E val);
}
